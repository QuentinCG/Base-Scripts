      <footer> <!-- Debut du bas de page -->
        <div id="bas_du_bas">
          <p id="w3c_compatibilite">
            <a href="https://validator.w3.org/check?uri=http%3A%2F%2Fteamspeak.comte-gaz.com%2Findex.php" target=_blank><img src="images/css_valide.png" title="Site valide CSS 3 (W3C n'est pas encore au point pour l'évaluation CSS 3 : Des propriétés propres à certains navigateurs ne sont pas reconnus)" alt="Valide CSS 3" /></a>
            <a href="https://validator.w3.org/check?uri=http%3A%2F%2Fteamspeak.comte-gaz.com%2Findex.php" target=_blank><img src="images/html_valide.png" title="Site valide HTML 5" alt="Valide HTML 5" /></a>
            <img src="images/IE.png" title="Site compatible avec Internet Explorer (cependant, les anciennes versions d'IE ne permettent pas un affichage optimal du site)"  alt="Intenet Explorer" />
            <img src="images/chrome.png" title="Site compatible avec Google Chrome"  alt="Google Chrome" />
            <img src="images/firefox.png" title="Site compatible avec Firefox" alt="firefox" />
            <img src="images/safari.png" title="Site compatible avec Safari"  alt="Safari" />
            <img src="images/opera.png" title="Site compatible avec Opéra"  alt="Opera" />
          </p>
          <p title="Merci de me contacter si vous souhaitez utiliser le code CSS/HTML du site">
          <a href="mentions_legales.php" id="mention_legal">Tous droits réservés © 2011-<?php echo date('Y'); ?></a>
          </p>
        </div>
      </footer>

    </div>

    <!-- Retour Haut -->
    <script src="js/jquery-1.7.2.min.js" type="text/javascript"></script>
    <script src="js/easing.js" type="text/javascript"></script>
    <script src="js/jquery.ui.totop.js" type="text/javascript"></script>
    <script type="text/javascript">$.noConflict();	jQuery(document).ready(function($) {$(document).ready(function() {$().UItoTop({ easingType: 'easeOutQuart' });});});</script>

    </body>
</html>