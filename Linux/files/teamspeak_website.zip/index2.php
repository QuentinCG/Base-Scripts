<html>


<script type="text/javascript">
  function resizeIframe(iframe) {
    iframe.height = iframe.contentWindow.document.body.scrollHeight + "px";
    iframe.width = iframe.contentWindow.document.body.scrollWidth + "px";
  }
</script>  


Welcome to this teamspeak server hosted by Quecg2.<br/>
<br/>
Have fun and troll as much as you want !<br/>
<br/>
Rule 1. Do not talk about /b/.<br/>
Rule 2. Do not talk about /b/.<br/>
<b>Only my friends are allowed to access this server.</b><br/>
<br/>
<iframe onload="resizeIframe(this)" allowtransparency="true" src="https://teamspeak.comte-gaz.com/ts3wi/tsviewpub.php?skey=0&sid=1&showicons=right&bgcolor=ffffff&fontcolor=000000" scrolling="auto" frameborder="0">Your Browser will not show Iframes</iframe>
</html>
