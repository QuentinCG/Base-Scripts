Teamspeak 3 Webinterface written by Psychokiller (Daniel P.)

Dev-Website: http://ts3.cs-united.de

This software uses the ts3admin.class.php from Par0noid (Stefan Z.)

Dev-Website: http://ts3admin.info
