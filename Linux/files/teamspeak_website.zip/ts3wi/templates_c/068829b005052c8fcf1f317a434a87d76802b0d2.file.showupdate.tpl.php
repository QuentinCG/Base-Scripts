<?php /* Smarty version Smarty3rc4, created on 2016-01-29 13:08:47
         compiled from "/var/www/teamspeak/ts3wi/templates/new/showupdate.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8865509556ab564fef23d1-34947028%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '068829b005052c8fcf1f317a434a87d76802b0d2' => 
    array (
      0 => '/var/www/teamspeak/ts3wi/templates/new/showupdate.tpl',
      1 => 1454069010,
    ),
  ),
  'nocache_hash' => '8865509556ab564fef23d1-34947028',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php if (isset($_smarty_tpl->getVariable('newwiversion')->value)){?>
<tr>
	<td class="green1 warning center" colspan="2">
	<?php echo $_smarty_tpl->getVariable('newwiversion')->value;?>

	</td>
<tr>
<?php }?>