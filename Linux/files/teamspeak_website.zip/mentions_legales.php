<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8"/>	<!-- type de codage -->
    <meta name="googlebot" content="noarchive"/> 
    <meta name="author" lang="fr" content="Quentin Comte-Gaz"/>
    <meta name="robots" content="noindex, nofollow"/>
    <link rel="icon" type="image/png" href="favicon.png" />
    <link rel="stylesheet" href="styles/style.css" /> <!-- insertion de la feuille css styles/style.css -->
        <!--[if lt IE 9]>
        <script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <!--[if lte IE 7]>
        <link rel="stylesheet" href="styles/style_ie.css" />
        <![endif]--> 
    <title>Mentions légales</title> 	<!-- titre -->
  </head>

  <?php include("hautdepage.php"); ?>

  <section>	<!--  Debut du corps de la page  -->
    <article id="article_haut">
      <h1>
      Mentions légales
      </h1>
      <p>
      L'intégralité du contenu de ce site, est propriété intellectuelle de Quentin Comte-Gaz, toute copie ou récupération d'images ou de textes, pourra faire l'objet de <strong>poursuites pénales</strong>.
      <br/>Si cependant vous voulez utiliser un élément de ce site, <strong>veuillez me contacter puis ajouter cette bannière en bas de votre page </strong>:<br/>
      <br/><a href="https://quentin.comte-gaz.com"><img src="images/banniere_externe.png"  title="Quentin Comte-Gaz a aidé (en partie) à faire ce site Web." alt="Quentin Comte-Gaz a aidé (en partie) à faire ce site Web." /></a>
      <br/><br/>
      Code de cette bannière :</br>
         <textarea id="zone" style="background: #ffffff; width: 500px; height: 120px; margin: 9px; overflow: scroll" rows="1" cols="1"><a href="https://quentin.comte-gaz.com"><img src="https://teamspeak.comte-gaz.com/images/banniere_externe.png"  title="Quentin Comte-Gaz a aidé (en partie) à faire ce site Web." alt="Quentin Comte-Gaz a aidé (en partie) à faire ce site Web." /></a></textarea>
      <br/><br/>
      
      Me contacter :<br/>
      <img src="images/mail.png"  title="Mon adresse e-mail" alt="Mon adresse e-mail" /><br/>
      <br/><br/></p>
    </article>
  </section>

  <?php include("basdepage.php"); ?>