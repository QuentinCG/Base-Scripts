<!DOCTYPE html><html><head>
    <meta charset="UTF-8"/>	<!-- type de codage -->
    <meta name="googlebot" content="noarchive"/> 
    <meta name="author" lang="fr" content="Quentin Comte-Gaz"/>
    <meta name="robots" content="noindex, nofollow"/>
    <link rel="icon" type="image/png" href="favicon.png" />
    <link rel="stylesheet" href="styles/style.css" /> <!-- insertion de la feuille css styles/style.css -->
        <!--[if lt IE 9]>
        <script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <!--[if lte IE 7]>
        <link rel="stylesheet" href="styles/style_ie.css" />
        <![endif]--> 
    <script type="text/javascript">
      function resizeIframe(iframe) {
        iframe.height = iframe.contentWindow.document.body.scrollHeight + "px";
        iframe.width = iframe.contentWindow.document.body.scrollWidth + "px";
      }
    </script>
    <title>La Team Disney, un état d'esprit</title> <!-- titre -->
  </head><?php include("hautdepage.php"); ?>

      <section><!--  Debut du corps de la page  -->
        <article id="article_haut"> <!-- Debut du premier article  -->
          <h1>
          Etat du serveur Teamspeak
          </h1>
          <p>
          <iframe onload="resizeIframe(this)"
                  src="ts3wi/tsviewpub.php?skey=0&sid=1&showicons=right&bgcolor=e6e6e6&fontcolor=404040"
                  scrolling="auto"
                  frameborder="0">Activez l'affichage des Iframes sur votre navigateur.</iframe>
          </p>
        </article>
      </section>

      <?php include("basdepage.php"); ?>