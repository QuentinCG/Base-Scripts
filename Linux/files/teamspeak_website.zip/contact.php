<!DOCTYPE html>

<head>
    <meta charset="UTF-8"/> <!-- type de codage -->
    <meta name="googlebot" content="noarchive"/> 
    <meta name="author" lang="fr" content="Quentin Comte-Gaz"/>
    <meta name="robots" content="noindex, nofollow"/>
    <link rel="icon" type="image/png" href="favicon.png" />
    <link rel="stylesheet" href="styles/style.css" /> <!-- insertion de la feuille css styles/style.css -->
        <!--[if lt IE 9]>
        <script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
        <![endif]-->
        <!--[if lte IE 7]>
        <link rel="stylesheet" href="styles/style_ie.css" />
        <![endif]--> 
    <title>Contacter Admin</title> <!-- titre -->
  </head>

      <?php include("hautdepage.php"); ?>

      <section> <!--  Debut du corps de la page  -->
        
        <article id="article_haut"> <!-- Debut du premier article  -->
          <h1>
          Me contacter :
          </h1>
          <p>
              <img src="images/lol.png" title="LoL" alt="E-Mail" class="contact" />
              &nbsp;&nbsp;<strong>Compte LoL</strong> :<br/>
              <span class="contact1"><b>Quecg3</b></span><br/>
              <br/>
              <img src="images/email.gif"  title="E-Mail" alt="E-Mail" class="contact" />
              &nbsp;&nbsp;<strong>Adresse E-Mail</strong> :<br/>
              <img src="images/mail.png"  title="Mon adresse e-mail" alt="Mon adresse e-mail" class="contact1" /><br/>
          </p>
        </article>
      </section>

      <?php include("basdepage.php"); ?>