<body><div id="page">

      <header> <!-- Debut du haut de page -->
        <div id="banniere"> <!-- Debut de la banniere haute -->
          <div id="description_banniere">
            <h1  title="Nom de team" id="nom_team">Team<br/>&nbsp;&nbsp;&nbsp;&nbsp;Disney</h1>
            <h2 title="info" id="description_team">La team de folie</h2>
          </div>
        </div>
      </header>

      <nav id="menu1"> <!-- Debut du menu -->
          <ul>
            <li class="menu" title="Aller à l'acceuil"><a href="index.php">Accueil</a></li>
            <li class="menu" title="Règles"><a href="regles.php">Règles</a></li>
            <li class="menu" title="Admins"><a href="admins.php">Admins</a></li>
            <li class="menu" title="Contact"><a href="contact.php">Contact</a></li>
          </ul>
      </nav>